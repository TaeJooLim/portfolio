package com.portfolio.erp.controller.admin.order;
	
import java.util.Calendar;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.portfolio.erp.model.employee.EmployeeVO;
import com.portfolio.erp.model.order.OrderVO;
import com.portfolio.erp.model.product.ProductVO;
import com.portfolio.erp.service.admin.order.OrderSrv;
import com.portfolio.erp.service.admin.product.ProductSrv;
import com.portfolio.erp.service.common.CommonSrv;
import com.portfolio.erp.service.regnlog.RegnlogSrv;

@Controller
public class OrderCtr {
	
	@Autowired
	ProductSrv productSrv;
	
	@Autowired
	OrderSrv orderSrv;
	
	@Autowired
	CommonSrv commonSrv;
	
	@Autowired
	RegnlogSrv regnlogSrv;
	
	
	@RequestMapping("/admin/order_insert")
	public ModelAndView getOrder(@RequestParam(defaultValue="p_name") String searchOpt, 
			@RequestParam(defaultValue="") String words) {
		
		ModelAndView mav = new ModelAndView();
		
		Calendar cal = Calendar.getInstance();

		int year = cal.get(Calendar.YEAR);
		int month = cal.get(Calendar.MONTH) + 1;
		int day = cal.get(Calendar.DAY_OF_MONTH);
		
		/*총무부 부서장*/
		EmployeeVO evo = commonSrv.getHeadInfo("400");	
		
		List<EmployeeVO> dList = regnlogSrv.getDepartmentList();
		List<ProductVO> prodList = productSrv.getProductList(searchOpt, words);
		
		mav.addObject("year", year);
		mav.addObject("month", month);
		mav.addObject("day", day);
		mav.addObject("dList", dList);
		mav.addObject("prodList", prodList);
		mav.addObject("headInfo", evo);
		mav.setViewName("erp/admin/erp_order/order_insert");
		
		return mav;
	}
	
	@RequestMapping("/admin/order_insert_set")
	@ResponseBody
	public void setOrder(@ModelAttribute OrderVO ovo ) {
		orderSrv.setOrderList(ovo);
	}
	
	@RequestMapping("/admin/order_list")
	public ModelAndView getOrderList(@ModelAttribute OrderVO ovo, @RequestParam(defaultValue="p_name") String searchOpt, 
			@RequestParam(defaultValue="") String words) {
		ModelAndView mav = new ModelAndView();
		
		Calendar cal = Calendar.getInstance();

		int year = cal.get(Calendar.YEAR);
		int month = cal.get(Calendar.MONTH) + 1;
		int day = cal.get(Calendar.DAY_OF_MONTH);
		
		String orderDepart = ovo.getOrderEmpTeam();
		String orderDocNum = (orderDepart + "_"+year+"_"+month+"_buy");
		ovo.setOrderDocNum(orderDocNum);
		
		List<OrderVO> list = orderSrv.getOrderList(orderDocNum);
		
		/*총무부 부서장*/
		EmployeeVO evo = commonSrv.getHeadInfo("400");	
		
		List<EmployeeVO> dList = regnlogSrv.getDepartmentList();
		List<ProductVO> prodList = productSrv.getProductList(searchOpt, words);
		
		int docNumCnt = orderSrv.chkDocNumCnt(orderDocNum);
		int confirmCnt = orderSrv.chkConfirmCnt(orderDocNum);
		
		System.out.println(docNumCnt);
		System.out.println(confirmCnt);
		
		mav.addObject("docNumCnt", docNumCnt);
		mav.addObject("confirmCnt ", confirmCnt);
		mav.addObject("year", year);
		mav.addObject("month", month);
		mav.addObject("day", day);
		mav.addObject("dList", dList);
		mav.addObject("prodList", prodList);
		mav.addObject("headInfo", evo);
		mav.addObject("orderList",list);
		mav.addObject("orderEmpTeam",orderDepart);
		mav.addObject("orderDocNum", orderDocNum);
		mav.setViewName("erp/admin/erp_order/order_insert");
		
		return mav;
	}
	
	@RequestMapping("/admin/order_pUnit_change")
	@ResponseBody
	public String getProdUnit(@ModelAttribute OrderVO ovo) {
		return orderSrv.getProdUnit(ovo.getOrderPName());
	}
	
	@RequestMapping("/admin/order_pBuy_change")
	@ResponseBody
	public int getProdBuy(@ModelAttribute OrderVO ovo) {
		return orderSrv.getProdBuy(ovo.getOrderPName());
	}
	
	@RequestMapping("/admin/order_delete_one")
	@ResponseBody
	public String deleteOne(@RequestParam int orderId) {
		orderSrv.deleteOne(orderId);
		return "success";
	}
	
	@RequestMapping("/admin/order_confirm_change")
	@ResponseBody
	public String confirmChange(@RequestParam int orderId) {
		orderSrv.confirmChange(orderId);
		return "success";
	}

	
	@RequestMapping("/admin/order_form")
	public ModelAndView getOrderForm(@ModelAttribute OrderVO ovo, @RequestParam String orderDocNum) {
		ModelAndView mav = new ModelAndView();
		
		List<OrderVO> list = orderSrv.getOrderList(orderDocNum);
		
		mav.setViewName("erp/admin/erp_order/order_form");
		
		return mav;
	}

}
