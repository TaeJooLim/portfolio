package com.portfolio.erp.model.order;

public class OrderVO {
	
	private int orderId;
	private String orderEmpTeam;
	private String orderEmpName;
	private String orderDate;
	private String orderPName;
	private int orderPAmount;
	private String orderPUnit;
	private int orderPBuy;
	private int orderTotalPrice;
	private String orderPurpose;
	private String orderDocNum;
	private String orderConfirm;
	private int orderSender;
	private int orderReceiver;
	
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public String getOrderEmpTeam() {
		return orderEmpTeam;
	}
	public void setOrderEmpTeam(String orderEmpTeam) {
		this.orderEmpTeam = orderEmpTeam;
	}
	public String getOrderEmpName() {
		return orderEmpName;
	}
	public void setOrderEmpName(String orderEmpName) {
		this.orderEmpName = orderEmpName;
	}
	public String getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}
	public String getOrderPName() {
		return orderPName;
	}
	public void setOrderPName(String orderPName) {
		this.orderPName = orderPName;
	}
	public int getOrderPAmount() {
		return orderPAmount;
	}
	public void setOrderPAmount(int orderPAmount) {
		this.orderPAmount = orderPAmount;
	}
	public String getOrderPUnit() {
		return orderPUnit;
	}
	public void setOrderPUnit(String orderPUnit) {
		this.orderPUnit = orderPUnit;
	}
	public int getOrderPBuy() {
		return orderPBuy;
	}
	public void setOrderPBuy(int orderPBuy) {
		this.orderPBuy = orderPBuy;
	}
	public int getOrderTotalPrice() {
		return orderTotalPrice;
	}
	public void setOrderTotalPrice(int orderTotalPrice) {
		this.orderTotalPrice = orderTotalPrice;
	}
	public String getOrderPurpose() {
		return orderPurpose;
	}
	public void setOrderPurpose(String orderPurpose) {
		this.orderPurpose = orderPurpose;
	}
	public String getOrderDocNum() {
		return orderDocNum;
	}
	public String setOrderDocNum(String orderDocNum) {
		return this.orderDocNum = orderDocNum;
	}
	public String getOrderConfirm() {
		return orderConfirm;
	}
	public void setOrderConfirm(String orderConfirm) {
		this.orderConfirm = orderConfirm;
	}
	public int getOrderSender() {
		return orderSender;
	}
	public void setOrderSender(int orderSender) {
		this.orderSender = orderSender;
	}
	public int getOrderReceiver() {
		return orderReceiver;
	}
	public void setOrderReceiver(int orderReceiver) {
		this.orderReceiver = orderReceiver;
	}
	

}
