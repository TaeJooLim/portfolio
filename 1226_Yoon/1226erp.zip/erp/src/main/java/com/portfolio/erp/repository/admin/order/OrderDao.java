package com.portfolio.erp.repository.admin.order;

import java.util.List;
import java.util.Map;

import com.portfolio.erp.model.order.OrderVO;

public interface OrderDao {
	
	public void setOrderList(OrderVO ovo);
	
	public List<OrderVO> getOrderList(String orderDocNum);
	
	public String getProdUnit(String orderPName);
	
	public int getProdBuy(String orderPName);
	
	public void deleteOne(int orderId);
	
	public void confirmChange(int orderId);
	
	public int chkDocNumCnt(String orderDocNum);
	
	public int chkConfirmCnt(String orderDocNum);

}
