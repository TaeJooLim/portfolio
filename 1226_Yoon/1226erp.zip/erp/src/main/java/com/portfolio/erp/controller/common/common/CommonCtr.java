package com.portfolio.erp.controller.common.common;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.portfolio.erp.model.employee.EmployeeVO;
import com.portfolio.erp.service.common.CommonSrv;

@Controller
public class CommonCtr {

	@Autowired
	CommonSrv commonSrv;
	
	public EmployeeVO getHeadInfo(String empDepartment) {
		EmployeeVO evo = commonSrv.getHeadInfo(empDepartment);
		return evo;
	}
}
