package com.portfolio.erp.controller.admin.contract;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.portfolio.erp.model.contract.ContractVO;
import com.portfolio.erp.service.admin.contract.ContractSrv;

@Controller
public class ContractCtr {
	
	@Autowired
	ContractSrv cSrv;
	
	@RequestMapping("/admin/contract/contract")
	public ModelAndView getContract() {	
		ModelAndView mav = new ModelAndView();
		
		mav.addObject("count",0);
		mav.setViewName("erp/admin/contract/contract");
		return mav;		
	}
	
	
	@RequestMapping("/admin/contract/contract_insert")
	@ResponseBody
	public int setContract(@ModelAttribute ContractVO cvo) {
		cvo.setContDocNum("0");
		String clientLicenseNumFk = cvo.getClientLicenseNumFk();	
		cSrv.setContract(cvo);

		int contID = cSrv.getID(clientLicenseNumFk);
		String clientCode = cSrv.getCode(clientLicenseNumFk,contID);
		String contDocNum = cvo.getTime()+ clientCode+ contID;
		cSrv.setContDocNum(contDocNum, contID);
		
		return contID;		
	}
	
	@RequestMapping("/admin/contract/contract_detail")
	public ModelAndView getContractDetail(@RequestParam int contID) {	
		ModelAndView mav = new ModelAndView();
		
		String contDocNum = cSrv.getcontDocNum(contID);
			
		mav.addObject("contID",contID);
		mav.addObject("contDocNum",contDocNum);
		mav.setViewName("erp/admin/contract/contract");		
		return mav;		
	}
	
	@RequestMapping("/admin/contract/contract_detail_list")
	public ModelAndView setContDpName(@RequestParam int contID) {
		ModelAndView mav = new ModelAndView();
		String contDocNum = cSrv.getcontDocNum(contID);
		
		mav.addObject("contID",contID);
		mav.addObject("contDocNum",contDocNum);
		mav.setViewName("erp/admin/contract/contract");		
		return mav;
	}
	
	
	@RequestMapping("/admin/contract/contract_detail_prod")
	public ModelAndView getContDpName(@ModelAttribute ContractVO cvo) {
		ModelAndView mav = new ModelAndView();
		List<ContractVO> list = cSrv.getContDList(cvo.getContDocNum());
		int count = cSrv.countCD(cvo.getContDocNum());
		
		mav.addObject("count",count);
		mav.addObject("list",list);
		mav.addObject("contID",cvo.getContID());
		mav.addObject("contDocNum",cvo.getContDocNum());
		
		cvo = cSrv.getproduct(cvo.getContDpName());

		mav.addObject("cvo",cvo);
		mav.setViewName("erp/admin/contract/contract");
		return mav;	
	}
	
	@RequestMapping("/admin/contract/contract_detail_insert")
	@ResponseBody
	public int setContD(@ModelAttribute ContractVO cvo) {
		
		int contID = cvo.getContID();
	
		cSrv.setContD(cvo);
	
		return contID;	
	}
	
	@RequestMapping("/admin/contract/contract_detail_delete")
	@ResponseBody
	public String setContDDel(
			@RequestParam int contDID) {	
		cSrv.setContDDel(contDID);
		return "success";		
	}

	@RequestMapping("/admin/contract/contract_list")
	public ModelAndView getContractList(
			@RequestParam(defaultValue = "") String words, 
			@RequestParam(defaultValue = "cont_doc_num") String searchOpt
			) {	
		ModelAndView mav = new ModelAndView();
		int count = cSrv.countC();
		List<ContractVO> list = cSrv.getcontlist(words,searchOpt);
		mav.addObject("list",list);
		mav.addObject("count",count);
		mav.setViewName("erp/admin/contract/contract_list");
		return mav;		
	}
	
	@RequestMapping("/admin/contract/contract_list_delete")
	@ResponseBody
	public String setContDel(
			@RequestParam int contID) {	
		cSrv.setContDel(contID);
		return "success";		
	}
	
	@RequestMapping("/admin/contract/contract_modify")
	public ModelAndView getContModify(@RequestParam String contDocNum,
			@ModelAttribute ContractVO cvo) {	
		ModelAndView mav = new ModelAndView();
		
		if(cvo.getContDpName() != null) {
			ContractVO prod = cSrv.getproduct(cvo.getContDpName());
			mav.addObject("cvo",prod);
		}
		
		int count = cSrv.countCD(contDocNum);
		cvo = cSrv.getcontDMOne(contDocNum);
		List<ContractVO> list = cSrv.getContDList(contDocNum);
		mav.addObject("contID",cvo.getContID());
		mav.addObject("contComName",cvo.getContComName());
		mav.addObject("contEmpCompany",cvo.getContEmpCompany());
		mav.addObject("contDepartName",cvo.getContDepartName());
		mav.addObject("contPositionName",cvo.getContPositionName());
		mav.addObject("contEmpName",cvo.getContEmpName());
		mav.addObject("contClientCompany",cvo.getContClientCompany());
		mav.addObject("contClientCeoName",cvo.getContClientCeoName());
		mav.addObject("contClientResponsibility",cvo.getContClientResponsibility());
		mav.addObject("contClientResCp",cvo.getContClientResCp());
		mav.addObject("contClientResEmail",cvo.getContClientResEmail());
		mav.addObject("contOrderDate",cvo.getContOrderDate());
		mav.addObject("contDueDate",cvo.getContDueDate());
		mav.addObject("contNote",cvo.getContNote());
		mav.addObject("clientLicenseNumFk",cvo.getClientLicenseNumFk());
		mav.addObject("list",list);
		mav.addObject("count",count);
		mav.addObject("contDocNum",contDocNum);
		mav.setViewName("erp/admin/contract/contract_modify");
		return mav;		
	}
	
	@RequestMapping("/admin/contract/contract_modify_delete")
	@ResponseBody
	public String setContDModDel(
			@RequestParam int contDID) {	
		cSrv.setContDDel(contDID);
		return "success";		
	}
	
	@RequestMapping("/admin/contract/contract_modify_update")
	@ResponseBody
	public String setContDModUp(
			@ModelAttribute ContractVO cvo) {	
		cSrv.setContDModUp(cvo);
		return "success";		
	}
	
	@RequestMapping("/admin/contract/contract_modify_insert")
	@ResponseBody
	public int setContDM(@ModelAttribute ContractVO cvo) {
		
		int contID = cvo.getContID();
	
		cSrv.setContD(cvo);
	
		return contID;	
	}
	
}
