$(function(){
    $("#tree").treeview({
        collapsed:true,
        animated:0,
        control:"#sidetreecontrol",
        persist: "location"
    });
});

