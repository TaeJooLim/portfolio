package com.portfolio.erp.controller.common;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.portfolio.erp.model.board.ArticleVO;
import com.portfolio.erp.model.company.CompanyVO;
import com.portfolio.erp.service.admin.board.BoardSrv;
import com.portfolio.erp.service.admin.company.CompanySrv;

@Controller
public class MainPageCtr {
	
	@Autowired
	CompanySrv companySrv;
	
	@Autowired
	BoardSrv bSrv;
	
	@RequestMapping("")
	public ModelAndView getMain() {
		ModelAndView mav = new ModelAndView();
		
		// 0. 회사정보 불러오기
		CompanyVO cvo = companySrv.getCompanyInfo();
		
		mav.addObject("comNum", cvo.getComNum());
		mav.addObject("comCeo", cvo.getComCeo());
		mav.addObject("comAddress", cvo.getComAddress());
		mav.addObject("comTel",cvo.getComTel());
		mav.addObject("comFax", cvo.getComFax());
		mav.addObject("comWebMenu", cvo.getComWebMenu());
		mav.addObject("comWebMenuUrl", cvo.getComWebMenuUrl());		
		mav.addObject("comWebTop", cvo.getComWebTop());
		mav.addObject("comWebBottom",cvo.getComWebBottom());
		mav.addObject("comWebCopyright", cvo.getComWebCopyright());
		
		// 1. 
		String boardWords = "";
		String boardSearchOpt = "subject";
		int startIndex = 0;
		int pageSize = 4;
		
		// 1. 사내공지사항 게시판 게시글목록 불러오기
		List<ArticleVO> companyBoard = bSrv.articleList("999com",boardWords,boardSearchOpt,startIndex,pageSize);
		mav.addObject("companyBoard",companyBoard);
		mav.addObject("comBoardNum", "999com");
		
		// 2. 문의사항 게시판 게시글목록 불러오기
		List<ArticleVO> qnaBoard = bSrv.articleList("999Qna",boardWords,boardSearchOpt,startIndex,pageSize);
		mav.addObject("qnaBoard",qnaBoard);
		mav.addObject("qnaBoardNum", "999Qna");
		
		
		mav.setViewName("erp/common/index");
		return mav;
	}

}
