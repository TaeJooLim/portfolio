package com.portfolio.erp.controller.admin.order;
	
import java.util.Calendar;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.portfolio.erp.model.employee.EmployeeVO;
import com.portfolio.erp.model.order.OrderVO;
import com.portfolio.erp.model.product.ProductVO;
import com.portfolio.erp.service.admin.order.OrderSrv;
import com.portfolio.erp.service.admin.product.ProductSrv;
import com.portfolio.erp.service.common.CommonSrv;
import com.portfolio.erp.service.regnlog.RegnlogSrv;

@Controller
public class OrderCtr {
	
	@Autowired
	ProductSrv productSrv;
	
	@Autowired
	OrderSrv orderSrv;
	
	@Autowired
	CommonSrv commonSrv;
	
	@Autowired
	RegnlogSrv regnlogSrv;
	
	
	@RequestMapping("/admin/order_insert")
	public ModelAndView getOrder(@RequestParam String empDepartment) {
		ModelAndView mav = new ModelAndView();
		
		// 날짜자동계산
		Calendar cal = Calendar.getInstance();
		int year = cal.get(Calendar.YEAR);
		int month = cal.get(Calendar.MONTH) + 1;
		int day = cal.get(Calendar.DAY_OF_MONTH);
		
		// 품명 불러오기
		List<ProductVO> pList = productSrv.getProductList("p_name", "");
		
		// 부서 불러오기
		List<EmployeeVO> dList = regnlogSrv.getDepartmentList();
		
		// 문서번호 자동완성(부서코드_년도_월_buy)
		String orderDocNum = empDepartment+"_"+year+"_"+month+"_buy";
		
		// 문서번호로 리스트 불러오기
		List<OrderVO> orderList = orderSrv.getOrderList(orderDocNum);
		
		/*총무부 부서장 id */
		EmployeeVO evo = commonSrv.getHeadInfo("400");	
		
		mav.addObject("year", year);
		mav.addObject("month", month);
		mav.addObject("day", day);
		mav.addObject("dList", dList);
		mav.addObject("prodList", pList);
		mav.addObject("headInfo", evo);
		mav.addObject("orderDocNum", orderDocNum);
		mav.addObject("orderList",orderList);
		mav.addObject("empDepartment", empDepartment);
		
		mav.setViewName("erp/admin/erp_order/order_insert");
		
		return mav;		
	}
	
	@RequestMapping("/admin/order_insert_set")
	@ResponseBody
	public void setOrder(@ModelAttribute OrderVO ovo ) {
		orderSrv.setOrderList(ovo);
	}
	
	@RequestMapping("/admin/order_pUnit_change")
	@ResponseBody
	public String getProdUnit(@ModelAttribute OrderVO ovo) {
		return orderSrv.getProdUnit(ovo.getOrderPName());
	}
	
	@RequestMapping("/admin/order_pBuy_change")
	@ResponseBody
	public int getProdBuy(@ModelAttribute OrderVO ovo) {
		return orderSrv.getProdBuy(ovo.getOrderPName());
	}
	
	@RequestMapping("/admin/order_delete_one")
	@ResponseBody
	public String deleteOne(@RequestParam int orderId) {
		orderSrv.deleteOne(orderId);
		return "success";
	}

	
	@RequestMapping("/admin/order_form")
	public ModelAndView getOrderForm(@ModelAttribute OrderVO ovo, @RequestParam String orderDocNum) {
		ModelAndView mav = new ModelAndView();
		
		List<OrderVO> list = orderSrv.getOrderList(orderDocNum);
		
		mav.setViewName("erp/admin/erp_order/order_form");
		
		return mav;
	}

}
