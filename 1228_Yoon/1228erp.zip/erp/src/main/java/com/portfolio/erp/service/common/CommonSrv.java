package com.portfolio.erp.service.common;

import com.portfolio.erp.model.employee.EmployeeVO;

public interface CommonSrv {
	public EmployeeVO getHeadInfo(String empDepartment);
}
