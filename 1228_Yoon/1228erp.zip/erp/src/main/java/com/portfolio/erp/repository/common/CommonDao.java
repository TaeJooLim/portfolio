package com.portfolio.erp.repository.common;

import com.portfolio.erp.model.employee.EmployeeVO;

public interface CommonDao {
	public EmployeeVO getHeadInfo(String empDepartment);
}
